---
layout: default
---

# License

From its first release in 2002, Secret Rabbit Code was under a dual licensing
scheme where people could chose to use it under the terms of the GNU General
Public License or pay for a commercial use license.

In 2016, thanks to a generous offer from Epic Games International, Secret Rabbit
Code was relicensed under the 2-clause BSD license.
